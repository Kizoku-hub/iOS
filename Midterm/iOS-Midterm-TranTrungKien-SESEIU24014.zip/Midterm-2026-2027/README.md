# Library Equipment Management (SwiftUI)

A small SwiftUI iOS app demonstrating an equipment library with three equipment categories:
- Laptop: processor, RAM, storage
- Tablet: screen size, battery capacity, digital pen support
- Digital camera: sensor resolution, lens type, video recording capacity

## Included features
- Nine sample items (three per category), with fixed sample data (no random generation).
- Equipment list with category filters and availability status.
- Equipment details and category-specific specifications.
- Borrowing and returning with validation and success/error alerts.
- Register new equipment and update permitted information.
- Encapsulation: ID and purchase year are immutable; status and mutable fields are changed through model methods.
- Inheritance: `Laptop`, `Tablet`, and `DigitalCamera` inherit from `Equipment`.

## Open in Xcode
1. Unzip the downloaded folder.
2. Open `LibraryEquipmentApp.xcodeproj` in Xcode.
3. Select an iPhone simulator (iOS 17 or later).
4. In the project settings, set a valid Development Team if Xcode asks.
5. Press Run.

The project uses SF Symbols as product illustrations, so no external image assets are required.

## Main source files
- `Equipment.swift`: base class, subclasses, equipment types and validation.
- `BorrowingRecord.swift`: borrowing transaction model.
- `LibraryManager.swift`: controller/business logic and sample data.
- `EquipmentListView.swift`: screen 1.
- `EquipmentDetailView.swift`: screen 2.
- `EquipmentManagementView.swift`: screen 3.
- `ContentView.swift`: bottom tab navigation.
