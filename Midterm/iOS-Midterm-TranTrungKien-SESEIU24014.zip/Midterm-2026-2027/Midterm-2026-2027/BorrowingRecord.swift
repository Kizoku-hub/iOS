import Foundation

struct BorrowingRecord: Identifiable {
    let id: UUID
    let borrower: String
    let equipmentID: String
    let borrowingDate: Date
    let expectedReturnDate: Date
    var actualReturnDate: Date?

    init(borrower: String, equipmentID: String, borrowingDate: Date, expectedReturnDate: Date) {
        self.id = UUID()
        self.borrower = borrower
        self.equipmentID = equipmentID
        self.borrowingDate = borrowingDate
        self.expectedReturnDate = expectedReturnDate
        self.actualReturnDate = nil
    }

    var isActive: Bool { actualReturnDate == nil }
}
