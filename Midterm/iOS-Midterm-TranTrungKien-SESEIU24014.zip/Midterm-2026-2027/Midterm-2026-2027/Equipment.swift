import Foundation
import Combine

enum EquipmentType: String, CaseIterable, Identifiable {
    case laptop = "Laptop"
    case tablet = "Tablet"
    case camera = "Camera"

    var id: String { rawValue }

    var symbol: String {
        switch self {
        case .laptop: return "laptopcomputer"
        case .tablet: return "ipad"
        case .camera: return "camera"
        }
    }
}

enum EquipmentStatus: String {
    case available = "Available"
    case onLoan = "On Loan"
}

class Equipment: ObservableObject, Identifiable {
    let id: String
    let purchaseYear: Int

    @Published private(set) var name: String
    @Published private(set) var manufacturer: String
    @Published private(set) var status: EquipmentStatus = .available

    var type: EquipmentType { fatalError("Subclasses must override type") }
    var symbol: String { type.symbol }

    init(id: String, name: String, manufacturer: String, purchaseYear: Int) {
        self.id = id
        self.name = name
        self.manufacturer = manufacturer
        self.purchaseYear = purchaseYear
    }

    func updateGeneralInfo(name: String, manufacturer: String) throws {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanManufacturer = manufacturer.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !cleanName.isEmpty else { throw LibraryError.invalidInput("Equipment name cannot be empty.") }
        guard !cleanManufacturer.isEmpty else { throw LibraryError.invalidInput("Manufacturer cannot be empty.") }

        self.name = cleanName
        self.manufacturer = cleanManufacturer
    }

    func markAsBorrowed() throws {
        guard status == .available else { throw LibraryError.notAvailable }
        status = .onLoan
    }

    func markAsReturned() throws {
        guard status == .onLoan else { throw LibraryError.notOnLoan }
        status = .available
    }
}

final class Laptop: Equipment {
    @Published private(set) var processor: String
    @Published private(set) var ramGB: Int
    @Published private(set) var storageGB: Int

    override var type: EquipmentType { .laptop }

    init(id: String, name: String, manufacturer: String, purchaseYear: Int,
         processor: String, ramGB: Int, storageGB: Int) {
        self.processor = processor
        self.ramGB = ramGB
        self.storageGB = storageGB
        super.init(id: id, name: name, manufacturer: manufacturer, purchaseYear: purchaseYear)
    }

    func updateSpecifications(processor: String, ramGB: Int, storageGB: Int) throws {
        let cleanProcessor = processor.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanProcessor.isEmpty else { throw LibraryError.invalidInput("Processor cannot be empty.") }
        guard ramGB > 0, storageGB > 0 else { throw LibraryError.invalidInput("RAM and storage must be greater than zero.") }
        self.processor = cleanProcessor
        self.ramGB = ramGB
        self.storageGB = storageGB
    }
}

final class Tablet: Equipment {
    @Published private(set) var screenSizeInches: Double
    @Published private(set) var batteryCapacityMah: Int
    @Published private(set) var supportsDigitalPen: Bool

    override var type: EquipmentType { .tablet }

    init(id: String, name: String, manufacturer: String, purchaseYear: Int,
         screenSizeInches: Double, batteryCapacityMah: Int, supportsDigitalPen: Bool) {
        self.screenSizeInches = screenSizeInches
        self.batteryCapacityMah = batteryCapacityMah
        self.supportsDigitalPen = supportsDigitalPen
        super.init(id: id, name: name, manufacturer: manufacturer, purchaseYear: purchaseYear)
    }

    func updateSpecifications(screenSizeInches: Double, batteryCapacityMah: Int, supportsDigitalPen: Bool) throws {
        guard screenSizeInches > 0, batteryCapacityMah > 0 else {
            throw LibraryError.invalidInput("Screen size and battery capacity must be greater than zero.")
        }
        self.screenSizeInches = screenSizeInches
        self.batteryCapacityMah = batteryCapacityMah
        self.supportsDigitalPen = supportsDigitalPen
    }
}

final class DigitalCamera: Equipment {
    @Published private(set) var sensorResolutionMP: Double
    @Published private(set) var lensType: String
    @Published private(set) var videoResolution: String

    override var type: EquipmentType { .camera }

    init(id: String, name: String, manufacturer: String, purchaseYear: Int,
         sensorResolutionMP: Double, lensType: String, videoResolution: String) {
        self.sensorResolutionMP = sensorResolutionMP
        self.lensType = lensType
        self.videoResolution = videoResolution
        super.init(id: id, name: name, manufacturer: manufacturer, purchaseYear: purchaseYear)
    }

    func updateSpecifications(sensorResolutionMP: Double, lensType: String, videoResolution: String) throws {
        let cleanLens = lensType.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanVideo = videoResolution.trimmingCharacters(in: .whitespacesAndNewlines)
        guard sensorResolutionMP > 0 else { throw LibraryError.invalidInput("Sensor resolution must be greater than zero.") }
        guard !cleanLens.isEmpty, !cleanVideo.isEmpty else {
            throw LibraryError.invalidInput("Lens type and video capacity cannot be empty.")
        }
        self.sensorResolutionMP = sensorResolutionMP
        self.lensType = cleanLens
        self.videoResolution = cleanVideo
    }
}
