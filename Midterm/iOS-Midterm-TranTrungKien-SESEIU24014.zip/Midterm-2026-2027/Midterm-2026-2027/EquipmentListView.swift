import SwiftUI

struct EquipmentListView: View {
    @EnvironmentObject private var library: LibraryManager
    @State private var selectedType: EquipmentType? = nil

    private var filteredEquipment: [Equipment] {
        guard let selectedType else { return library.equipment }
        return library.equipment.filter { $0.type == selectedType }
    }

    var body: some View {
        VStack(spacing: 12) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    filterButton("All", isSelected: selectedType == nil) { selectedType = nil }
                    ForEach(EquipmentType.allCases) { type in
                        filterButton(type.rawValue, isSelected: selectedType == type) { selectedType = type }
                    }
                }
                .padding(.horizontal)
            }

            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(filteredEquipment) { item in
                        NavigationLink {
                            EquipmentDetailView(item: item)
                        } label: {
                            EquipmentRow(item: item)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 12)
            }
        }
        .navigationTitle("Library Equipment")
        .background(Color(uiColor: .systemGroupedBackground))
    }

    private func filterButton(_ title: String, isSelected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline.weight(.semibold))
                .padding(.horizontal, 16)
                .padding(.vertical, 9)
                .background(isSelected ? Color.indigo : Color.gray.opacity(0.12), in: Capsule())
                .foregroundStyle(isSelected ? .white : .primary)
        }
    }
}
