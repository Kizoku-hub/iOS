import SwiftUI

struct EquipmentRow: View {
    @ObservedObject var item: Equipment

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: item.symbol)
                .font(.system(size: 30))
                .foregroundStyle(.indigo)
                .frame(width: 62, height: 62)
                .background(Color.indigo.opacity(0.10), in: RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 5) {
                Text(item.name).font(.headline)
                Text("\(item.type.rawValue) • \(item.id)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(item.manufacturer).font(.caption).foregroundStyle(.secondary)
            }

            Spacer(minLength: 4)

            Text(item.status.rawValue)
                .font(.caption.weight(.semibold))
                .foregroundStyle(item.status == .available ? .green : .orange)
                .padding(.horizontal, 9)
                .padding(.vertical, 6)
                .background((item.status == .available ? Color.green : Color.orange).opacity(0.12), in: Capsule())
        }
        .padding(12)
        .background(.background, in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.gray.opacity(0.16)))
    }
}
