import SwiftUI

struct EquipmentManagementView: View {
    @EnvironmentObject private var library: LibraryManager
    @State private var mode = "Register"
    @State private var selectedType: EquipmentType = .laptop
    @State private var selectedExistingID = ""

    @State private var id = ""
    @State private var name = ""
    @State private var manufacturer = ""
    @State private var purchaseYear = ""
    @State private var processor = ""
    @State private var ram = ""
    @State private var storage = ""
    @State private var screenSize = ""
    @State private var battery = ""
    @State private var supportsPen = false
    @State private var sensor = ""
    @State private var lens = ""
    @State private var video = ""

    @State private var alertMessage = ""
    @State private var showingAlert = false

    private var selectedEquipment: Equipment? {
        library.equipment.first { $0.id == selectedExistingID }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Picker("Mode", selection: $mode) {
                    Text("Register").tag("Register")
                    Text("Update").tag("Update")
                }
                .pickerStyle(.segmented)

                if mode == "Register" {
                    typePicker
                    generalForm(isUpdate: false)
                    specificationForm
                    submitButton
                } else {
                    updateSelector
                    if let item = selectedEquipment {
                        generalForm(isUpdate: true)
                        specificationForm
                        submitButton
                    } else {
                        ContentUnavailableView("Select equipment", systemImage: "shippingbox", description: Text("Choose an existing item above to update its permitted information."))
                    }
                }
            }
            .padding()
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Equipment Management")
        .alert("Library Equipment", isPresented: $showingAlert) {
            Button("OK", role: .cancel) { }
        } message: { Text(alertMessage) }
        .onChange(of: selectedType) { _, _ in clearSpecificationFields() }
        .onChange(of: selectedExistingID) { _, _ in loadSelectedEquipment() }
        .onChange(of: mode) { _, newMode in
            if newMode == "Register" {
                selectedExistingID = ""
                clearAllFields()
            }
        }
    }

    private var typePicker: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Equipment Type").font(.headline)
            HStack {
                ForEach(EquipmentType.allCases) { type in
                    Button {
                        selectedType = type
                    } label: {
                        VStack(spacing: 7) {
                            Image(systemName: type.symbol).font(.title2)
                            Text(type.rawValue).font(.caption.bold())
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(selectedType == type ? Color.indigo.opacity(0.15) : Color.gray.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(selectedType == type ? Color.indigo : Color.clear, lineWidth: 1.5))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(15)
        .background(.background, in: RoundedRectangle(cornerRadius: 16))
    }

    private var updateSelector: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Select Equipment to Update").font(.headline)
            Picker("Equipment", selection: $selectedExistingID) {
                Text("Choose an item").tag("")
                ForEach(library.equipment) { item in
                    Text("\(item.name) (\(item.id))").tag(item.id)
                }
            }
            .pickerStyle(.menu)
            if let item = selectedEquipment {
                Label("\(item.type.rawValue) • ID and purchase year are locked", systemImage: "lock.fill")
                    .font(.caption).foregroundStyle(.secondary)
                Text("Specifications for \(item.type.rawValue)").font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(15)
        .background(.background, in: RoundedRectangle(cornerRadius: 16))
    }

    private func generalForm(isUpdate: Bool) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("General Information").font(.headline)
            if isUpdate {
                lockedRow("Equipment ID", selectedEquipment?.id ?? "")
            } else {
                field("Equipment ID", text: $id, prompt: "e.g. LAP-004")
            }
            field("Name", text: $name, prompt: "Equipment name")
            field("Manufacturer", text: $manufacturer, prompt: "Manufacturer")
            if isUpdate {
                lockedRow("Purchase year", "\(selectedEquipment?.purchaseYear ?? 0)")
            } else {
                field("Purchase year", text: $purchaseYear, prompt: "e.g. 2025", keyboard: .numberPad)
            }
        }
        .padding(15)
        .background(.background, in: RoundedRectangle(cornerRadius: 16))
    }

    @ViewBuilder
    private var specificationForm: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Specifications").font(.headline)
            let type = mode == "Update" ? (selectedEquipment?.type ?? selectedType) : selectedType
            switch type {
            case .laptop:
                field("Processor", text: $processor, prompt: "e.g. Intel Core i5")
                field("RAM (GB)", text: $ram, prompt: "e.g. 16", keyboard: .numberPad)
                field("Storage (GB)", text: $storage, prompt: "e.g. 512", keyboard: .numberPad)
            case .tablet:
                field("Screen size (inches)", text: $screenSize, prompt: "e.g. 11", keyboard: .decimalPad)
                field("Battery capacity (mAh)", text: $battery, prompt: "e.g. 7600", keyboard: .numberPad)
                Toggle("Supports digital pen", isOn: $supportsPen)
            case .camera:
                field("Sensor resolution (MP)", text: $sensor, prompt: "e.g. 24.2", keyboard: .decimalPad)
                field("Lens type", text: $lens, prompt: "e.g. 18-45mm")
                field("Video recording", text: $video, prompt: "e.g. 4K UHD")
            }
        }
        .padding(15)
        .background(.background, in: RoundedRectangle(cornerRadius: 16))
    }

    private var submitButton: some View {
        Button(action: submit) {
            Label(mode == "Register" ? "Register Equipment" : "Save Equipment Changes",
                  systemImage: mode == "Register" ? "plus.circle.fill" : "checkmark.circle.fill")
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .foregroundStyle(.white)
                .background(Color.indigo, in: RoundedRectangle(cornerRadius: 13))
        }
    }

    private func submit() {
        do {
            if mode == "Register" {
                guard let year = Int(purchaseYear), year > 0 else {
                    throw LibraryError.invalidInput("Enter a valid purchase year.")
                }
                let item: Equipment
                switch selectedType {
                case .laptop:
                    guard let r = Int(ram), let s = Int(storage) else { throw LibraryError.invalidInput("Enter valid RAM and storage values.") }
                    item = Laptop(id: id, name: name, manufacturer: manufacturer, purchaseYear: year, processor: processor, ramGB: r, storageGB: s)
                case .tablet:
                    guard let size = Double(screenSize), let cap = Int(battery) else { throw LibraryError.invalidInput("Enter valid screen size and battery values.") }
                    item = Tablet(id: id, name: name, manufacturer: manufacturer, purchaseYear: year, screenSizeInches: size, batteryCapacityMah: cap, supportsDigitalPen: supportsPen)
                case .camera:
                    guard let mp = Double(sensor) else { throw LibraryError.invalidInput("Enter a valid sensor resolution.") }
                    item = DigitalCamera(id: id, name: name, manufacturer: manufacturer, purchaseYear: year, sensorResolutionMP: mp, lensType: lens, videoResolution: video)
                }
                try library.register(item)
                alertMessage = "Equipment registered successfully."
                clearAllFields()
            } else {
                guard let item = selectedEquipment else { throw LibraryError.equipmentNotFound }
                try item.updateGeneralInfo(name: name, manufacturer: manufacturer)
                if let x = item as? Laptop {
                    guard let r = Int(ram), let s = Int(storage) else { throw LibraryError.invalidInput("Enter valid RAM and storage values.") }
                    try x.updateSpecifications(processor: processor, ramGB: r, storageGB: s)
                } else if let x = item as? Tablet {
                    guard let size = Double(screenSize), let cap = Int(battery) else { throw LibraryError.invalidInput("Enter valid screen size and battery values.") }
                    try x.updateSpecifications(screenSizeInches: size, batteryCapacityMah: cap, supportsDigitalPen: supportsPen)
                } else if let x = item as? DigitalCamera {
                    guard let mp = Double(sensor) else { throw LibraryError.invalidInput("Enter a valid sensor resolution.") }
                    try x.updateSpecifications(sensorResolutionMP: mp, lensType: lens, videoResolution: video)
                }
                alertMessage = "Equipment updated successfully. ID and purchase year were not changed."
            }
        } catch {
            alertMessage = error.localizedDescription
        }
        showingAlert = true
    }

    private func loadSelectedEquipment() {
        guard let item = selectedEquipment else { clearAllFields(); return }
        name = item.name
        manufacturer = item.manufacturer
        if let x = item as? Laptop {
            selectedType = .laptop
            processor = x.processor; ram = "\(x.ramGB)"; storage = "\(x.storageGB)"
        } else if let x = item as? Tablet {
            selectedType = .tablet
            screenSize = "\(x.screenSizeInches)"; battery = "\(x.batteryCapacityMah)"; supportsPen = x.supportsDigitalPen
        } else if let x = item as? DigitalCamera {
            selectedType = .camera
            sensor = "\(x.sensorResolutionMP)"; lens = x.lensType; video = x.videoResolution
        }
    }

    private func clearSpecificationFields() {
        processor = ""; ram = ""; storage = ""
        screenSize = ""; battery = ""; supportsPen = false
        sensor = ""; lens = ""; video = ""
    }

    private func clearAllFields() {
        id = ""; name = ""; manufacturer = ""; purchaseYear = ""
        selectedExistingID = ""
        clearSpecificationFields()
    }

    private func field(_ title: String, text: Binding<String>, prompt: String, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            TextField(prompt, text: text)
                .keyboardType(keyboard)
                .textFieldStyle(.roundedBorder)
        }
    }

    private func lockedRow(_ title: String, _ value: String) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.caption).foregroundStyle(.secondary)
                Text(value).font(.body)
            }
            Spacer()
            Image(systemName: "lock.fill").foregroundStyle(.secondary)
        }
        .padding(10)
        .background(Color.gray.opacity(0.08), in: RoundedRectangle(cornerRadius: 9))
    }
}
