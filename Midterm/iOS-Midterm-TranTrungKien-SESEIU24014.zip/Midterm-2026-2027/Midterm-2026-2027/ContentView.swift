import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var library: LibraryManager
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack {
                EquipmentListView()
            }
            .tabItem { Label("Equipment", systemImage: "shippingbox") }
            .tag(0)

            NavigationStack {
                EquipmentManagementView()
            }
            .tabItem { Label("Manage", systemImage: "slider.horizontal.3") }
            .tag(1)
        }
        .tint(.indigo)
    }
}
