import SwiftUI

struct EquipmentDetailView: View {
    @EnvironmentObject private var library: LibraryManager
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var item: Equipment

    @State private var isEditing = false
    @State private var name = ""
    @State private var manufacturer = ""
    @State private var processor = ""
    @State private var ram = ""
    @State private var storage = ""
    @State private var screenSize = ""
    @State private var battery = ""
    @State private var supportsPen = false
    @State private var sensor = ""
    @State private var lens = ""
    @State private var video = ""
    @State private var borrower = ""
    @State private var borrowingDate = Date()
    @State private var expectedReturnDate = Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date()
    @State private var showingBorrowSheet = false
    @State private var alertMessage = ""
    @State private var showingAlert = false

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                VStack(spacing: 10) {
                    Image(systemName: item.symbol)
                        .font(.system(size: 58))
                        .foregroundStyle(.indigo)
                    Text(item.name).font(.title2.bold()).multilineTextAlignment(.center)
                    Text(item.type.rawValue).foregroundStyle(.secondary)
                    statusLabel
                }
                .frame(maxWidth: .infinity)
                .padding(22)
                .background(.background, in: RoundedRectangle(cornerRadius: 18))

                VStack(alignment: .leading, spacing: 12) {
                    sectionTitle("General Information")
                    if isEditing {
                        editableField("Name", text: $name)
                        editableField("Manufacturer", text: $manufacturer)
                    } else {
                        infoRow("ID", item.id)
                        infoRow("Name", item.name)
                        infoRow("Manufacturer", item.manufacturer)
                    }
                    infoRow("Purchase year", "\(item.purchaseYear)")
                }
                .padding(16)
                .background(.background, in: RoundedRectangle(cornerRadius: 18))

                VStack(alignment: .leading, spacing: 12) {
                    sectionTitle("Specifications")
                    specificationFields
                }
                .padding(16)
                .background(.background, in: RoundedRectangle(cornerRadius: 18))

                VStack(spacing: 10) {
                    if isEditing {
                        actionButton("Submit Changes", icon: "checkmark", color: .green, action: saveChanges)
                        actionButton("Cancel Editing", icon: "xmark", color: .gray) { isEditing = false }
                    } else {
                        if item.status == .available {
                            actionButton("Borrow Equipment", icon: "arrow.down.circle", color: .indigo) {
                                showingBorrowSheet = true
                            }
                        } else {
                            actionButton("Return Equipment", icon: "arrow.uturn.backward.circle", color: .orange) {
                                performReturn()
                            }
                        }
                        actionButton("Edit Information", icon: "pencil", color: .gray, action: beginEditing)
                    }
                }
                .padding(16)
                .background(.background, in: RoundedRectangle(cornerRadius: 18))
            }
            .padding()
        }
        .background(Color(uiColor: .systemGroupedBackground))
        .navigationTitle("Equipment Details")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showingBorrowSheet) { borrowSheet }
        .alert("Library Equipment", isPresented: $showingAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
    }

    @ViewBuilder
    private var specificationFields: some View {
        if let laptop = item as? Laptop {
            if isEditing {
                editableField("Processor", text: $processor)
                editableField("RAM (GB)", text: $ram, keyboard: .numberPad)
                editableField("Storage (GB)", text: $storage, keyboard: .numberPad)
            } else {
                infoRow("Processor", laptop.processor)
                infoRow("RAM", "\(laptop.ramGB) GB")
                infoRow("Storage", "\(laptop.storageGB) GB")
            }
        } else if let tablet = item as? Tablet {
            if isEditing {
                editableField("Screen size (inches)", text: $screenSize, keyboard: .decimalPad)
                editableField("Battery (mAh)", text: $battery, keyboard: .numberPad)
                Toggle("Supports digital pen", isOn: $supportsPen)
            } else {
                infoRow("Screen size", "\(String(format: "%.1f", tablet.screenSizeInches)) inches")
                infoRow("Battery", "\(tablet.batteryCapacityMah) mAh")
                infoRow("Digital pen", tablet.supportsDigitalPen ? "Supported" : "Not supported")
            }
        } else if let camera = item as? DigitalCamera {
            if isEditing {
                editableField("Sensor resolution (MP)", text: $sensor, keyboard: .decimalPad)
                editableField("Lens type", text: $lens)
                editableField("Video recording", text: $video)
            } else {
                infoRow("Sensor resolution", "\(String(format: "%.1f", camera.sensorResolutionMP)) MP")
                infoRow("Lens type", camera.lensType)
                infoRow("Video recording", camera.videoResolution)
            }
        }
    }

    private var statusLabel: some View {
        Text(item.status.rawValue)
            .font(.subheadline.bold())
            .foregroundStyle(item.status == .available ? .green : .orange)
            .padding(.horizontal, 12).padding(.vertical, 7)
            .background((item.status == .available ? Color.green : Color.orange).opacity(0.12), in: Capsule())
    }

    private var borrowSheet: some View {
        NavigationStack {
            Form {
                TextField("Student or lecturer name", text: $borrower)
                DatePicker("Borrowing date", selection: $borrowingDate, displayedComponents: .date)
                DatePicker("Expected return", selection: $expectedReturnDate, in: borrowingDate..., displayedComponents: .date)
            }
            .navigationTitle("Borrow Equipment")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showingBorrowSheet = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Confirm") { performBorrow() }
                }
            }
        }
        .presentationDetents([.medium])
    }

    private func beginEditing() {
        name = item.name
        manufacturer = item.manufacturer
        if let x = item as? Laptop {
            processor = x.processor; ram = "\(x.ramGB)"; storage = "\(x.storageGB)"
        } else if let x = item as? Tablet {
            screenSize = "\(x.screenSizeInches)"; battery = "\(x.batteryCapacityMah)"; supportsPen = x.supportsDigitalPen
        } else if let x = item as? DigitalCamera {
            sensor = "\(x.sensorResolutionMP)"; lens = x.lensType; video = x.videoResolution
        }
        isEditing = true
    }

    private func saveChanges() {
        do {
            try item.updateGeneralInfo(name: name, manufacturer: manufacturer)
            if let x = item as? Laptop {
                guard let r = Int(ram), let s = Int(storage) else { throw LibraryError.invalidInput("RAM and storage must be whole numbers.") }
                try x.updateSpecifications(processor: processor, ramGB: r, storageGB: s)
            } else if let x = item as? Tablet {
                guard let size = Double(screenSize), let cap = Int(battery) else { throw LibraryError.invalidInput("Enter valid screen size and battery capacity.") }
                try x.updateSpecifications(screenSizeInches: size, batteryCapacityMah: cap, supportsDigitalPen: supportsPen)
            } else if let x = item as? DigitalCamera {
                guard let mp = Double(sensor) else { throw LibraryError.invalidInput("Enter a valid sensor resolution.") }
                try x.updateSpecifications(sensorResolutionMP: mp, lensType: lens, videoResolution: video)
            }
            isEditing = false
            showMessage("Equipment information updated successfully.")
        } catch { showMessage(error.localizedDescription) }
    }

    private func performBorrow() {
        do {
            try library.borrow(equipmentID: item.id, borrower: borrower, borrowingDate: borrowingDate, expectedReturnDate: expectedReturnDate)
            showingBorrowSheet = false
            borrower = ""
            borrowingDate = Date()
            expectedReturnDate = Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date()
            showMessage("Borrowing recorded successfully.")
        } catch { showMessage(error.localizedDescription) }
    }

    private func performReturn() {
        do {
            try library.returnEquipment(equipmentID: item.id)
            showMessage("Equipment returned successfully.")
        } catch { showMessage(error.localizedDescription) }
    }

    private func showMessage(_ message: String) {
        alertMessage = message
        showingAlert = true
    }

    private func sectionTitle(_ title: String) -> some View {
        Text(title).font(.headline)
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).multilineTextAlignment(.trailing)
        }
        .font(.subheadline)
    }

    private func editableField(_ title: String, text: Binding<String>, keyboard: UIKeyboardType = .default) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            TextField(title, text: text)
                .keyboardType(keyboard)
                .textFieldStyle(.roundedBorder)
        }
    }

    private func actionButton(_ title: String, icon: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .foregroundStyle(.white)
                .background(color, in: RoundedRectangle(cornerRadius: 12))
        }
    }
}
