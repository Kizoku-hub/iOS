import SwiftUI

@main
struct LibraryEquipmentApp: App {
    @StateObject private var library = LibraryManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(library)
        }
    }
}
