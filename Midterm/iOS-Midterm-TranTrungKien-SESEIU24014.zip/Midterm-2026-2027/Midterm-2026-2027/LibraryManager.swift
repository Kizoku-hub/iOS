import Foundation
import Combine

enum LibraryError: LocalizedError {
    case invalidInput(String)
    case duplicateID
    case equipmentNotFound
    case notAvailable
    case notOnLoan
    case activeRecordNotFound
    case invalidDates

    var errorDescription: String? {
        switch self {
        case .invalidInput(let message): return message
        case .duplicateID: return "An equipment item with this ID already exists."
        case .equipmentNotFound: return "Equipment could not be found."
        case .notAvailable: return "This equipment is already on loan."
        case .notOnLoan: return "This equipment is not currently on loan."
        case .activeRecordNotFound: return "No active borrowing record was found."
        case .invalidDates: return "Expected return date must be on or after the borrowing date."
        }
    }
}

final class LibraryManager: ObservableObject {
    @Published private(set) var equipment: [Equipment]
    @Published private(set) var borrowingRecords: [BorrowingRecord] = []

    init() {
        equipment = [
            Laptop(id: "LAP-001", name: "IdeaPad Slim 5", manufacturer: "Lenovo", purchaseYear: 2023, processor: "Intel Core i5", ramGB: 16, storageGB: 512),
            Laptop(id: "LAP-002", name: "MacBook Air", manufacturer: "Apple", purchaseYear: 2024, processor: "Apple M3", ramGB: 16, storageGB: 512),
            Laptop(id: "LAP-003", name: "Aspire 5", manufacturer: "Acer", purchaseYear: 2022, processor: "Intel Core i7", ramGB: 8, storageGB: 1024),
            Tablet(id: "TAB-001", name: "iPad Air", manufacturer: "Apple", purchaseYear: 2024, screenSizeInches: 11, batteryCapacityMah: 7600, supportsDigitalPen: true),
            Tablet(id: "TAB-002", name: "Galaxy Tab S9", manufacturer: "Samsung", purchaseYear: 2023, screenSizeInches: 11, batteryCapacityMah: 8400, supportsDigitalPen: true),
            Tablet(id: "TAB-003", name: "Tab M10", manufacturer: "Lenovo", purchaseYear: 2022, screenSizeInches: 10.1, batteryCapacityMah: 5000, supportsDigitalPen: false),
            DigitalCamera(id: "CAM-001", name: "EOS R50", manufacturer: "Canon", purchaseYear: 2023, sensorResolutionMP: 24.2, lensType: "RF-S 18-45mm", videoResolution: "4K"),
            DigitalCamera(id: "CAM-002", name: "Z 50", manufacturer: "Nikon", purchaseYear: 2022, sensorResolutionMP: 20.9, lensType: "NIKKOR Z DX 16-50mm", videoResolution: "4K UHD"),
            DigitalCamera(id: "CAM-003", name: "Alpha 6400", manufacturer: "Sony", purchaseYear: 2021, sensorResolutionMP: 24.2, lensType: "E 16-50mm", videoResolution: "4K")
        ]
    }

    func equipment(withID id: String) -> Equipment? {
        equipment.first { $0.id == id }
    }

    func register(_ item: Equipment) throws {
        guard !item.id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw LibraryError.invalidInput("Equipment ID cannot be empty.")
        }
        guard !equipment.contains(where: { $0.id.caseInsensitiveCompare(item.id) == .orderedSame }) else {
            throw LibraryError.duplicateID
        }
        guard !item.name.isEmpty, !item.manufacturer.isEmpty, item.purchaseYear > 0 else {
            throw LibraryError.invalidInput("Please provide valid general information.")
        }
        equipment.append(item)
    }

    func borrow(equipmentID: String, borrower: String, borrowingDate: Date, expectedReturnDate: Date) throws {
        let cleanBorrower = borrower.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanBorrower.isEmpty else { throw LibraryError.invalidInput("Borrower name cannot be empty.") }
        guard expectedReturnDate >= borrowingDate else { throw LibraryError.invalidDates }
        guard let item = equipment(withID: equipmentID) else { throw LibraryError.equipmentNotFound }

        try item.markAsBorrowed()
        borrowingRecords.append(
            BorrowingRecord(borrower: cleanBorrower, equipmentID: equipmentID,
                            borrowingDate: borrowingDate, expectedReturnDate: expectedReturnDate)
        )
    }

    func returnEquipment(equipmentID: String) throws {
        guard let item = equipment(withID: equipmentID) else { throw LibraryError.equipmentNotFound }
        guard let index = borrowingRecords.lastIndex(where: { $0.equipmentID == equipmentID && $0.isActive }) else {
            throw LibraryError.activeRecordNotFound
        }
        try item.markAsReturned()
        borrowingRecords[index].actualReturnDate = Date()
    }
}
